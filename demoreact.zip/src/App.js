import React from "react";
import Login from "./Page/login.page";

const App = () => {
  return (
    <React.Fragment>
      <Login />
    </React.Fragment>
  );
};
export default App;
