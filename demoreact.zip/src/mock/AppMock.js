export const studentList = [
  {
    studentId: 1,
    name: "Tri",
  },
  {
    studentId: 2,
    name: "Thinh",
  },
];
